﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using Dapper;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using WebApplication.Model;
using Newtonsoft.Json;

namespace WebApplication.Services
{
    public class DbEmployeeService
    {
        DynamicParameters parameters = new DynamicParameters();
        string connetionString = @"Data Source=SUNERU;Initial Catalog=TrainingSanduni;User ID=stpluser;Password=tommya";
        public void InsertEmployee(int id, DbEmployee employee, string option)
        { 
            string sqlQuery = "InsertNewEmployee";
            string jsondata = JsonConvert.SerializeObject(employee);
            parameters.Add("@id", id);
            parameters.Add("@employee", jsondata);
            parameters.Add("@option", option);
            using (SqlConnection connection = new SqlConnection(connetionString))
            {
                connection.Execute(sqlQuery, parameters, commandType: System.Data.CommandType.StoredProcedure);
            }
        }

        public List<DbEmployee> GetEmployee()
        {
            string sqlQuery = "GetEmployee";
            using (SqlConnection connection = new SqlConnection(connetionString))
            {
                return connection.Query<DbEmployee>(sqlQuery, commandType: System.Data.CommandType.StoredProcedure).ToList<DbEmployee>();
                
            }
        }

        public void DeleteEmployee(int id,string option)
        {
            string sqlQuery = "AllAction";
            parameters.Add("@id", id);
            parameters.Add("@option", option);
            using (SqlConnection connection = new SqlConnection(connetionString))
            {
                connection.Execute(sqlQuery, parameters, commandType: System.Data.CommandType.StoredProcedure);
            }
        }

        public List<DbEmployee> SelectEmployee(int id, string option)
        {
            string sqlQuery = "AllAction";
            parameters.Add("@id", id);
            parameters.Add("@option", option);
            using (SqlConnection connection = new SqlConnection(connetionString))
                if (id==-999)
                {
                    return connection.Query<DbEmployee>(sqlQuery, parameters, commandType: System.Data.CommandType.StoredProcedure).ToList<DbEmployee>();
                }
                else
                {
                    return connection.Query<DbEmployee>(sqlQuery, parameters, commandType: System.Data.CommandType.StoredProcedure).ToList<DbEmployee>();
                }
        }

    }
}
            
