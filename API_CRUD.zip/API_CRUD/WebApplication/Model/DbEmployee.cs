﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication.Model
{
    public class DbEmployee
    {
            public int ID;
            public string Name;
            public string Address;
            public string Email;
        
    }
}
