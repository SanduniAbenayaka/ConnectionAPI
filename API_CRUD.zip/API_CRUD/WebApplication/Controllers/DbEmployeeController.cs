﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using WebApplication.Model;
using WebApplication.Services;


namespace WebApplication.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DbEmployeeController : ControllerBase
    {
        DbEmployeeService dbEmployeeService = new DbEmployeeService();

        [HttpGet()]
        public ActionResult<List<DbEmployee>> Get()
        {
            return dbEmployeeService.GetEmployee();
        }

        [HttpGet("{id}")]
        public ActionResult<List<DbEmployee>> Get(int id)
        {
            return dbEmployeeService.SelectEmployee(id, "SelectOne");
        }

        [HttpGet("ExceptId/{id}")]
        public ActionResult<List<DbEmployee>> ExceptId(int id)
        {
            return dbEmployeeService.SelectEmployee(id, "SelectAllExceptId");
        }


        [HttpGet("AllEmployee")]
        public ActionResult<List<DbEmployee>> AllEmployee()
        {
            return dbEmployeeService.SelectEmployee(-999, "SelectAll");
        }


        [HttpPost]
        public void Post([FromBody]DbEmployee employee)
        {
            dbEmployeeService.InsertEmployee(-999, employee, "Insert");
        }

       
        [HttpPut("Update/{id}")]
        public void Update(int id, [FromBody] DbEmployee employee)
        {
            dbEmployeeService.InsertEmployee(id, employee, "Update");
        }

        // DELETE 
        [HttpDelete("Delete/{id}")]
        public void Delete(int id)
        {
            dbEmployeeService.DeleteEmployee(id,"Delete");
        }


    }
}