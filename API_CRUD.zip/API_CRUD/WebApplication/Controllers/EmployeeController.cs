﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace WebApplication.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        // GET api/employee
        [HttpGet]
        public ActionResult<IEnumerable<string>> Get()
        {
            return new string[] { " Employee Details" };
        }

        // GET 
        //api/employee/GetAllEmployees

        [HttpGet("GetAllEmployees")]
        public ActionResult<IEnumerable<Employee>> GetallEmployees()
        {
            return EmployeeList.Emp;
        }

        // GET 
        //api/employee/GetEmployee/1

        [HttpGet("GetEmployee/{id}")]
        public ActionResult<Employee> GetEmployee(int id)
        {
            return EmployeeList.Emp.Find(item => item.id == id);
        }

        // GET 
        //api/employee/GetEmployeeByName/sandu

        [HttpGet("GetEmployeeByName/{name}")]
        public ActionResult<Employee> GetEmployeeByName(string name)
        {
            List<Employee> list1 = new List<Employee>();
            var result = (from emp in EmployeeList.Emp where emp.name == name select emp).ToList();
            foreach (Employee e in result)
            {
                list1.Add(e);
            }
            return Ok(list1);
        }

        // GET 
        //api/employee/GetEmployeeByAddress/town

        [HttpGet("GetEmployeeByAddress/{address}")]
        public ActionResult<Employee> GetEmployeeByAddress(string address)
        {
            List<Employee> list2 = new List<Employee>();
            var result = (from emp in EmployeeList.Emp where emp.address == address select emp).ToList();
            foreach (Employee e in result)
            {
                list2.Add(e);
            }
            return Ok(list2);
        }

        // POST 
        //api/employee/PostEmployee

        [HttpPost("PostEmployee")]
        public string PostEmployee([FromBody] Employee value)
        {
            var val = EmployeeList.Emp.Find(item => item.id == value.id);
            if (val == null)
            {
                EmployeeList.Emp.Add(value);
                return " Add successfully";
            }

            else
            {
                return "Employee already exist. ";
            }

        }
        // PUT 
        //api/employee/UpdateEmployee/1

        [HttpPut("UpdateEmployee/{id}")]
        public string Put(int id, [FromBody] Employee value)
        {
            try
            {
                var updateemp = EmployeeList.Emp.Find(item => item.id == id);
                updateemp.name = value.name;
                updateemp.address = value.address;
                return "Updated successfully";
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return "Id not found";
            }


        }

        // DELETE 
        //api/employee/DeleteEmployee/1

        [HttpDelete("DeleteEmployee/{id}")]
        public string Delete(int id)
        {
            var deleteEmployee = EmployeeList.Emp.Find(item => item.id == id);
            if (deleteEmployee != null)
            {
                EmployeeList.Emp.Remove(deleteEmployee);
                return "Deleted successfully";
            }
            else
            {
                return "Id not found";
            }
        }

    }

    public class Employee
    {
        public int id;
        public string name;
        public string address;

    }

    public static class EmployeeList
    {
        public static List<Employee> Emp = new List<Employee>();
    }
}
