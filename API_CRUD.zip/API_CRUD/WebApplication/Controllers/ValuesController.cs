﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace WebApplication.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ValuesController : ControllerBase
    {
        // GET api/values
        [HttpGet]
        public ActionResult<IEnumerable<string>> Get()
        {
            return new string[] { "Welcome" };
        }

        // GET 
        //api/values/GetAllEmployees

        [HttpGet("GetAllEmployees")]
        public ActionResult<IEnumerable<Employee>> GetallEmployees()
        {
            return EmployeeList.Emp;
        }

        // GET 
        //api/values/GetEmployee/1

        [HttpGet("GetEmployee/{id}")]
        public ActionResult<Employee> GetEmployee(int id)
        {
            return EmployeeList.Emp.Find(item=>item.id==id);
        }

        // POST 
        //api/values/PostEmployee

        [HttpPost("PostEmployee")]
        public string PostEmployee ([FromBody] Employee value)
        {
            var val = EmployeeList.Emp.Find(item => item.id == value.id);
            if (val==null)
            {
                EmployeeList.Emp.Add(value);
                return " Add successfully";
            }
            
            else{
                return "Employee already exist. ";
            }
           
        }
        // PUT 
        //api/values/UpdateEmployee/1

        [HttpPut("UpdateEmployee/{id}")]
        public string Put(int id, [FromBody] Employee value)
        {
            try
            {
                var updateemp = EmployeeList.Emp.Find(item => item.id == id);
                updateemp.name = value.name;
                updateemp.address = value.address;
                return "Updated successfully";
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return "Id not found";
            }


        }

        // DELETE 
       //api/values/DeleteEmployee/1

        [HttpDelete("DeleteEmployee/{id}")]
        public void Delete(int id)
        {
            var deleteemp = EmployeeList.Emp.Find(item => item.id == id);
            EmployeeList.Emp.Remove(deleteemp);
        }
    }

    public class Employee
    {
        public int id;
        public string name;
        public string address;

    }

    public static class EmployeeList
    {
       public static  List<Employee> Emp = new List<Employee>();
    }
}
